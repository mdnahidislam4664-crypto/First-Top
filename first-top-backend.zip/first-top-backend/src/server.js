require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const { Server } = require('socket.io');

const connectDB = require('./config/db');
const errorHandler = require('./middlewares/error.middleware');
const initChatSocket = require('./sockets/chat.socket');

// ডেটাবেস সংযোগ
connectDB();

const app = express();
const server = http.createServer(app);

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'production') {
  app.use(morgan('dev'));
}

// Socket.io রিয়েল-টাইম কনফিগারেশন
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
});
initChatSocket(io);

// বেসিক হেলথ চেক
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', message: 'First Top API Server সম্পূর্ণ সচল রয়েছে।' });
});

// সমস্ত API রাউট মাউন্ট
app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/videos', require('./routes/video.routes'));
app.use('/api/chats', require('./routes/chat.routes'));
app.use('/api/wallet', require('./routes/wallet.routes'));
app.use('/api/settings', require('./routes/settings.routes'));
app.use('/api/monetization', require('./routes/monetization.routes'));
app.use('/api/social', require('./routes/social.routes')); // নতুন সোশাল রাউট
app.use('/api/admin', require('./routes/admin.routes'));   // নতুন অ্যাডমিন রাউট

// গ্লোবাল এরর হ্যান্ডলার
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`[Server] First Top ব্যাক-এন্ড পোর্ট ${PORT}-এ সফলভাবে রান করছে।`);
});