const admin = require('../config/firebase');

/**
 * অফলাইন ইউজারের ফোনে পুশ নোটিফিকেশন পাঠানো
 * @param {string} fcmToken - ইউজারের ডিভাইস রেজিস্ট্রেশন টোকেন
 * @param {object} payload - নোটিফিকেশনের টাইটেল, বডি ও মেটাডেটা
 */
exports.sendPushNotification = async (fcmToken, { title, body, data = {} }) => {
  if (!fcmToken) return;

  const message = {
    token: fcmToken,
    notification: {
      title,
      body,
    },
    data: {
      ...data,
      click_action: 'FLUTTER_NOTIFICATION_CLICK',
    },
    android: {
      priority: 'high',
      notification: {
        sound: 'default',
        channelId: 'first_top_messages',
      },
    },
  };

  try {
    const response = await admin.messaging().send(message);
    console.log(`[FCM Push Sent]: ${response}`);
    return response;
  } catch (error) {
    console.error(`[FCM Push Error]: ${error.message}`);
  }
};const