const ffmpeg = require('fluent-ffmpeg');

/**
 * ডাউনলোডের জন্য ভিডিওতে "First Top - @username" ওয়াটারমার্ক বসানো
 */
exports.applyWatermark = (inputPath, outputPath, username) => {
  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .videoFilters([
        `drawtext=text='First Top - @${username}':x=w-tw-20:y=h-th-20:fontsize=24:fontcolor=white:box=1:boxcolor=black@0.5:boxborderw=5`,
      ])
      .output(outputPath)
      .on('end', () => resolve(outputPath))
      .on('error', (err) => reject(err))
      .run();
  });
};

/**
 * ভিডিও থেকে আলাদা ব্যাকগ্রাউন্ড অডিও (MP3) আলাদা করা
 */
exports.extractAudioFromVideo = (inputVideoPath, outputAudioPath) => {
  return new Promise((resolve, reject) => {
    ffmpeg(inputVideoPath)
      .output(outputAudioPath)
      .noVideo()
      .audioCodec('libmp3lame')
      .on('end', () => resolve(outputAudioPath))
      .on('error', (err) => reject(err))
      .run();
  });
};const