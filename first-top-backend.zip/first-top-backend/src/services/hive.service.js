const axios = require('axios');

/**
 * Hive Moderation API দিয়ে ভিডিও স্ক্যান করা
 * @param {string} mediaUrl - ভিডিওর পাবলিক URL
 * @returns {Promise<{isClean: boolean, details: any}>}
 */
exports.scanVideoWithHive = async (mediaUrl) => {
  try {
    const response = await axios.post(
      process.env.HIVE_API_URL,
      { media_url: mediaUrl },
      {
        headers: {
          Authorization: `token ${process.env.HIVE_API_KEY}`,
          'Content-Type': 'application/json',
        },
        timeout: 10000, // ১০ সেকেন্ড টাইমআউট
      }
    );

    const classes = response.data?.status?.[0]?.response?.output?.[0]?.classes || [];

    // ক্ষতিকর বা বেআইনি বিষয়ের স্কোর ৮০% (০.৮) এর বেশি হলে ক্ষতিকর হিসেবে গণ্য হবে
    const harmful = classes.some(
      (item) =>
        ['nsfw', 'violence', 'hate_speech', 'illegal_acts'].includes(item.class) &&
        item.score > 0.8
    );

    return {
      isClean: !harmful,
      details: classes,
    };
  } catch (error) {
    console.error(`[Hive API Error]: ${error.message}`);
    // এপিআই ডাউন থাকলে নিরাপত্তার স্বার্থে ফলস রিটার্ন করবে
    return { isClean: false, error: error.message };
  }
};const