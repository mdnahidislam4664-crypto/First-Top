const { PutObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const s3Client = require('../config/b2');

/**
 * ফ্রন্ট-এন্ড থেকে সরাসরি Backblaze B2-তে আপলোডের জন্য Presigned URL তৈরি
 * @param {string} fileName - ফাইলের নাম
 * @param {string} fileType - ফাইলের MIME Type (যেমন: video/mp4)
 * @returns {Promise<{uploadUrl: string, fileUrl: string}>}
 */
exports.generatePresignedUploadUrl = async (fileName, fileType) => {
  const fileKey = `videos/${Date.now()}_${fileName}`;

  const command = new PutObjectCommand({
    Bucket: process.env.B2_BUCKET_NAME,
    Key: fileKey,
    ContentType: fileType,
  });

  // URL-এর মেয়াদ থাকবে ১৫ মিনিট (৯০০ সেকেন্ড)
  const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 900 });
  const fileUrl = `${process.env.B2_ENDPOINT}/${process.env.B2_BUCKET_NAME}/${fileKey}`;

  return { uploadUrl, fileUrl };
};const