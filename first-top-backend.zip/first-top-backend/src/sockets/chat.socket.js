const jwt = require('jsonwebtoken');
const Message = require('../models/chat.model');
const User = require('../models/user.model');
const { sendPushNotification } = require('../services/fcm.service');

// অনলাইন ইউজারদের ট্র্যাক রাখার ম্যাপ (userId -> socketId)
const onlineUsers = new Map();

/**
 * Socket.io রিয়েল-টাইম চ্যাট ইভেন্ট হ্যান্ডলার
 */
const initChatSocket = (io) => {
  // ১. সকেট কানেকশন অথেন্টিকেশন মিডলওয়্যার (JWT টোকেন যাচাই)
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(' ')[1];
      if (!token) {
        return next(new Error('অননুমোদিত সকেট কানেকশন! টোকেন দেওয়া হয়নি।'));
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.userId = decoded.id;
      next();
    } catch (err) {
      return next(new Error('অবৈধ বা মেয়াদোত্তীর্ণ টোকেন!'));
    }
  });

  io.on('connection', async (socket) => {
    const userId = socket.userId;
    onlineUsers.set(userId, socket.id);
    console.log(`[Socket Connected] User ${userId} Socket ID: ${socket.id}`);

    // ইউজার অনলাইনে আসার পর তার পেন্ডিং মেসেজগুলো 'Delivered' (status: 1) করা
    try {
      const pendingMessages = await Message.find({ receiver: userId, status: 0 });
      if (pendingMessages.length > 0) {
        await Message.updateMany({ receiver: userId, status: 0 }, { $set: { status: 1 } });

        // প্রেরকদের ডেলিভারি নিশ্চিতকরণ আপডেট পাঠানো
        pendingMessages.forEach((msg) => {
          const senderSocketId = onlineUsers.get(msg.sender.toString());
          if (senderSocketId) {
            io.to(senderSocketId).emit('message_status_update', {
              messageId: msg._id,
              status: 1, // Delivered
            });
          }
        });
      }
    } catch (e) {
      console.error('[Socket Sync Error]:', e.message);
    }

    // ২. মেসেজ পাঠানোর ইভেন্ট (send_message)
    socket.on('send_message', async (data) => {
      try {
        const { receiverId, text, media_url } = data;
        const receiverSocketId = onlineUsers.get(receiverId);

        // রিসিভার অনলাইনে থাকলে Delivered (1), অফলাইনে থাকলে Sent (0)
        let initialStatus = receiverSocketId ? 1 : 0;

        // ডেটাবেসে মেসেজ সংরক্ষণ
        const newMessage = await Message.create({
          sender: userId,
          receiver: receiverId,
          text: text || '',
          media_url: media_url || '',
          status: initialStatus,
        });

        // প্রেরকের কাছে মেসেজ সেভ হওয়ার কনফার্মেশন পাঠানো
        socket.emit('message_sent', newMessage);

        if (receiverSocketId) {
          // রিসিভার অনলাইনে থাকলে রিয়েল-টাইমে মেসেজ পাঠানো
          io.to(receiverSocketId).emit('receive_message', newMessage);
        } else {
          // রিসিভার অফলাইনে থাকলে Firebase FCM পুশ নোটিফিকেশন পাঠানো
          const [receiver, sender] = await Promise.all([
            User.findById(receiverId).select('fcm_token'),
            User.findById(userId).select('username'),
          ]);

          if (receiver && receiver.fcm_token) {
            await sendPushNotification(receiver.fcm_token, {
              title: `@${sender?.username || 'কেউ একজন'} আপনাকে মেসেজ পাঠিয়েছেন`,
              body: text || 'একটি মিডিয়া ফাইল পাঠিয়েছেন',
              data: {
                senderId: userId.toString(),
                type: 'CHAT_MESSAGE',
              },
            });
          }
        }
      } catch (error) {
        socket.emit('error', { message: 'মেসেজ পাঠানো সম্ভব হয়নি।' });
      }
    });

    // ৩. রিড রিসিট: চ্যাট স্ক্রিন ওপেন করলে সব মেসেজ 'Seen' (2) করা
    socket.on('mark_as_seen', async ({ senderId }) => {
      try {
        await Message.updateMany(
          { sender: senderId, receiver: userId, status: { $ne: 2 } },
          { $set: { status: 2 } }
        );

        // প্রেরককে জানিয়ে দেওয়া যে তার মেসেজ দেখা হয়েছে
        const senderSocketId = onlineUsers.get(senderId);
        if (senderSocketId) {
          io.to(senderSocketId).emit('conversation_seen', {
            seenBy: userId,
            status: 2, // Seen
          });
        }
      } catch (error) {
        console.error('[Mark As Seen Error]:', error.message);
      }
    });

    // ৪. টাইপিং ইন্ডিকেটর ইভেন্ট
    socket.on('typing', ({ receiverId, isTyping }) => {
      const receiverSocketId = onlineUsers.get(receiverId);
      if (receiverSocketId) {
        io.to(receiverSocketId).emit('user_typing', { senderId: userId, isTyping });
      }
    });

    // ৫. ডিসকানেক্ট হ্যান্ডলার
    socket.on('disconnect', () => {
      onlineUsers.delete(userId);
      console.log(`[Socket Disconnected] User ${userId}`);
    });
  });
};

module.exports = initChatSocket;