const admin = require('firebase-admin');

/**
 * Firebase Admin SDK ইনিশিয়ালাইজেশন
 * ইউজার অফলাইনে থাকলে ব্যাকগ্রাউন্ডে পুশ নোটিফিকেশন পাঠানোর কাজে এটি ব্যবহৃত হয়
 */
try {
  const serviceAccount = process.env.FIREBASE_SERVICE_ACCOUNT_JSON
    ? JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)
    : null;

  if (serviceAccount) {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
    });
    console.log('[Firebase] Firebase Admin SDK সফলভাবে ইনিশিয়ালাইজ হয়েছে।');
  } else {
    console.warn('[Firebase Warning] Firebase সার্ভিস অ্যাকাউন্ট ক্রেডেনশিয়াল পাওয়া যায়নি!');
  }
} catch (error) {
  console.error(`[Firebase Init Error]: ${error.message}`);
}

module.exports = admin;