const mongoose = require('mongoose');

/**
 * MongoDB ডেটাবেস কানেকশন সেটআপ
 * রেন্ডার (Render) বা ক্লাউড হোস্টিংয়ে হাই অ্যাভেইলেবিলিটি নিশ্চিত করতে অপ্টিমাইজড
 */
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      autoIndex: true, // স্কিমা ইনডেক্সিং এনাবল রাখা
    });
    console.log(`[Database] MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`[Database Error] ${error.message}`);
    process.exit(1);
  }
};

module.exports = connectDB;