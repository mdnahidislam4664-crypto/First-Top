const { S3Client } = require('@aws-sdk/client-s3');

/**
 * Backblaze B2 (S3-Compatible) ক্লায়েন্ট কনফিগারেশন
 * ফ্রন্ট-এন্ড সরাসরি ব্যাকব্লেজে ভিডিও আপলোড করার জন্য এই ক্লায়েন্ট দিয়ে Presigned URL জেনারেট করা হবে
 */
const s3Client = new S3Client({
  endpoint: process.env.B2_ENDPOINT,
  region: process.env.B2_REGION,
  credentials: {
    accessKeyId: process.env.B2_KEY_ID,
    secretAccessKey: process.env.B2_APP_KEY,
  },
  forcePathStyle: true,
});

module.exports = s3Client;