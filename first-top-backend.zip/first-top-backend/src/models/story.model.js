const mongoose = require('mongoose');

const storySchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    media_url: {
      type: String,
      required: true,
    },
    media_type: {
      type: String,
      enum: ['image', 'video'],
      default: 'video',
    },
    viewers: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    ],
    // TTL ইনডেক্স: ডেটাবেসে তৈরির ঠিক ২৪ ঘণ্টা (86400 সেকেন্ড) পর স্বয়ংক্রিয়ভাবে মুছে যাবে
    createdAt: {
      type: Date,
      default: Date.now,
      expires: 86400, // 24 hours in seconds
    },
  }
);

module.exports = mongoose.model('Story', storySchema);