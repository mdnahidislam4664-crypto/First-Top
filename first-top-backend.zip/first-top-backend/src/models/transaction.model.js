const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema(
  {
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null, // ডিপোজিটের ক্ষেত্রে সেন্ডার নাল থাকবে
      index: true,
    },
    receiver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    amount: {
      type: Number,
      required: [true, 'কয়েনের পরিমাণ আবশ্যক'],
      min: [1, 'পরিমাণ কমপক্ষে ১ হতে হবে'],
    },
    type: {
      type: String,
      enum: ['gift', 'deposit', 'withdrawal', 'ad_revenue'],
      required: true,
      index: true,
    },
    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'rejected'],
      default: 'pending',
      index: true,
    },
    payment_method: {
      type: String,
      enum: ['bkash', 'nagad', 'rocket', 'bank', 'in_app'],
      default: 'in_app',
    },
    transaction_id: {
      type: String,
      trim: true,
      default: '',
    },
    admin_note: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Transaction', transactionSchema);