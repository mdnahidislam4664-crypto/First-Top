const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema(
  {
    video: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Video',
      required: true,
      index: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    text: {
      type: String,
      required: [true, 'কমেন্ট টেক্সট আবশ্যক'],
      maxlength: 300,
      trim: true,
    },
    is_pinned: {
      type: Boolean,
      default: false,
    },
    parent_comment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Comment',
      default: null,
    },
    likes_count: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: true }
);

commentSchema.index({ video: 1, is_pinned: -1, createdAt: -1 });

module.exports = mongoose.model('Comment', commentSchema);