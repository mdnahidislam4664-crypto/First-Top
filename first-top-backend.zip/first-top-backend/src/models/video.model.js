const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    video_url: { type: String, required: true },
    thumbnail_url: { type: String, default: '' },
    caption: { type: String, maxlength: 300, default: '' },
    tags: [{ type: String, trim: true, index: true }],

    // জিপিএস ও এরিয়া লোকেশন (GeoJSON 2dsphere)
    location_name: { type: String, default: 'Bangladesh' },
    location: {
      type: {
        type: String,
        enum: ['Point'],
        default: 'Point',
      },
      coordinates: {
        type: [Number], // [longitude, latitude]
        default: [90.4125, 23.8103], // ঢাকা
      },
    },

    duet_original_video: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Video',
      default: null,
    },
    has_poll: { type: Boolean, default: false },
    poll_data: {
      question: String,
      options: [{ text: String, votes: { type: Number, default: 0 } }],
    },

    is_pinned: { type: Boolean, default: false },
    allow_comments: { type: Boolean, default: true },

    moderation_status: {
      type: String,
      enum: ['pending', 'approved', 'rejected'],
      default: 'pending',
      index: true,
    },

    views_count: { type: Number, default: 0 },
    view_duration_count: { type: Number, default: 0 },
    likes_count: { type: Number, default: 0 },
    shares_count: { type: Number, default: 0 },
    comments_count: { type: Number, default: 0 },

    is_highlighted: { type: Boolean, default: false, index: true },
  },
  { timestamps: true }
);

videoSchema.index({ location: '2dsphere' });
videoSchema.index({ moderation_status: 1, is_highlighted: -1, createdAt: -1 });

module.exports = mongoose.model('Video', videoSchema);