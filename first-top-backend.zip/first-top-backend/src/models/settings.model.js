const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema(
  {
    // ১. ডাবল অ্যাড কন্ট্রোল ইঞ্জিন (Ad Engine)
    ad_control_mode: {
      type: String,
      enum: ['by_count', 'by_time', 'hybrid'],
      default: 'hybrid', // 'by_count' = ভিডিও সংখ্যা অনুযায়ী, 'by_time' = সেকেন্ড অনুযায়ী, 'hybrid' = যেটি আগে ঘটবে
    },
    ad_frequency_video_count: {
      type: Number,
      default: 5, // প্রতি ৫টি ভিডিও পর পর অ্যাড
    },
    ad_interval_seconds: {
      type: Number,
      default: 120, // প্রতি ১২০ সেকেন্ড (২ মিনিট) পর পর অ্যাড
    },
    ad_base_cpm_rate: {
      type: Number,
      default: 0.02,
    },

    // AdMob IDs
    admob_banner_id: { type: String, default: '' },
    admob_interstitial_id: { type: String, default: '' },
    admob_rewarded_id: { type: String, default: '' },

    // ২. রেভিনিউ শেয়ারিং পারসেন্টেজ
    creator_revenue_share_percentage: { type: Number, default: 50 },
    platform_revenue_share_percentage: { type: Number, default: 50 },

    // ৩. মনিটাইজেশন ডায়নামিক শর্ত
    monetization_min_views: { type: Number, default: 10000 },
    monetization_min_followers: { type: Number, default: 1000 },

    // ৪. কয়েন ও ক্যাশআউট রেট
    coin_price_bdt: { type: Number, default: 2.0 }, // ১ কয়েন = ২ টাকা
    min_withdrawal_bdt: { type: Number, default: 500 }, // সর্বনিম্ন ৫০০ টাকা হলে উইথড্র
    payment_numbers: {
      bkash: { type: String, default: '01XXXXXXXXX' },
      nagad: { type: String, default: '01XXXXXXXXX' },
      rocket: { type: String, default: '01XXXXXXXXX' },
      upay: { type: String, default: '01XXXXXXXXX' },
    },

    // ৫. জিপিএস ও এরিয়া রেডিয়াস
    default_nearby_radius_km: { type: Number, default: 25 },

    // ৬. প্ল্যাটফর্ম মাস্টার সুইচ (Kill Switches)
    is_app_in_maintenance: { type: Boolean, default: false },
    enable_comments_globally: { type: Boolean, default: true },
    enable_gifting_globally: { type: Boolean, default: true },
    enable_withdrawals_globally: { type: Boolean, default: true },

    privacy_policy_url: { type: String, default: 'https://firsttop.app/privacy' },
    terms_of_service_url: { type: String, default: 'https://firsttop.app/terms' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('GlobalSettings', settingsSchema);