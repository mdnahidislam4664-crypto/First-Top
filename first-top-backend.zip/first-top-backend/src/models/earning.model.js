const mongoose = require('mongoose');

const earningSchema = new mongoose.Schema(
  {
    creator: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    video: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Video',
      required: true,
    },
    total_ad_revenue: {
      type: Number,
      required: true,
    },
    creator_share: {
      type: Number,
      required: true, // ৫০% অথবা ০%
    },
    platform_share: {
      type: Number,
      required: true, // ৫০% অথবা ১০০%
    },
    date: {
      type: Date,
      default: Date.now,
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

earningSchema.index({ creator: 1, date: -1 });

module.exports = mongoose.model('Earning', earningSchema);