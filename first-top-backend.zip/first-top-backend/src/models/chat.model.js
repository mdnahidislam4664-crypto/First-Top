const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema(
  {
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    receiver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    text: {
      type: String,
      trim: true,
      default: '',
    },
    media_url: {
      type: String,
      default: '',
    },
    /**
     * ৩-স্টেট রিড রিসিট লজিক:
     * 0 = Sent (সার্ভারে জমা হয়েছে, রিসিভার অফলাইনে)
     * 1 = Delivered (রিসিভার অনলাইনে রয়েছে এবং মেসেজ পেয়েছে)
     * 2 = Seen (রিসিভার চ্যাট ওপেন করে পড়েছে)
     */
    status: {
      type: Number,
      enum: [0, 1, 2],
      default: 0,
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// হিস্ট্রি দ্রুত লোডের জন্য কম্পাউন্ড ইনডেক্স
messageSchema.index({ sender: 1, receiver: 1, createdAt: -1 });

module.exports = mongoose.model('Message', messageSchema);const