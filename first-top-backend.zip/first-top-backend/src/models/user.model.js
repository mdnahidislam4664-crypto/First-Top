const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: [true, 'ইউজারনেম আবশ্যক'],
      unique: true,
      trim: true,
      lowercase: true,
      minlength: 3,
      maxlength: 30,
      index: true,
    },
    email: {
      type: String,
      required: [true, 'ইমেইল আবশ্যক'],
      unique: true,
      trim: true,
      lowercase: true,
      match: [/\S+@\S+\.\S+/, 'একটি ভ্যালিড ইমেইল দিন'],
      index: true,
    },
    password: {
      type: String,
      required: [true, 'পাসওয়ার্ড আবশ্যক'],
      minlength: 6,
      select: false, // ডিফল্ট কোয়েরিতে পাসওয়ার্ড যাতে সবার সামনে না আসে
    },
    avatar: {
      type: String,
      default: 'https://via.placeholder.com/150',
    },
    bio: {
      type: String,
      maxlength: 150,
      default: '',
    },
    // আর্থিক লেনদেনের ওয়ালেট
    wallet_balance: {
      type: Number,
      default: 0,
      min: [0, 'ব্যালেন্স শূন্যের নিচে নামতে পারবে না'],
    },
    // মনিটাইজেশন ও ক্রিয়েটর মেট্রিকস
    total_views: {
      type: Number,
      default: 0,
    },
    followers_count: {
      type: Number,
      default: 0,
    },
    following_count: {
      type: Number,
      default: 0,
    },
    is_monetized: {
      type: Boolean,
      default: false,
    },
    // অটো-পেনাল্টি ও সিকিউরিটি
    strike_count: {
      type: Number,
      default: 0,
    },
    is_suspended: {
      type: Boolean,
      default: false,
    },
    token_version: {
      type: Number,
      default: 0, // অ্যাকাউন্ট সাসপেন্ড হলে আগের সব টোকেন বাতিল করার জন্য
    },
    // অফলাইন পুশ নোটিফিকেশন টোকেন
    fcm_token: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

/**
 * পাসওয়ার্ড ডেটাবেসে সেভ করার পূর্বে Bcrypt দিয়ে হ্যাশ করা
 */
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

/**
 * লগইনের সময় পাসওয়ার্ড ভেরিফিকেশন হেল্পার
 */
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);