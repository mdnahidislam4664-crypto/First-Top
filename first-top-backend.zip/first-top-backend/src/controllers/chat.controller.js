const Message = require('../models/chat.model');
const User = require('../models/user.model');

/**
 * @desc    দুই ইউজারের চ্যাট হিস্ট্রি ফেচ করা (প্যাজিনেশন সহ)
 * @route   GET /api/chats/:receiverId
 * @access  Private
 */
exports.getChatHistory = async (req, res, next) => {
  try {
    const { receiverId } = req.params;
    const currentUserId = req.user._id;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 30;
    const skip = (page - 1) * limit;

    const messages = await Message.find({
      $or: [
        { sender: currentUserId, receiver: receiverId },
        { sender: receiverId, receiver: currentUserId },
      ],
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      data: messages.reverse(), // ক্লায়েন্টে পুরনো থেকে নতুন ক্রমানুসারে সাজানো
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    ইউজারের ডিভাইসের FCM টোকেন আপডেট করা
 * @route   POST /api/chats/fcm-token
 * @access  Private
 */
exports.updateFcmToken = async (req, res, next) => {
  try {
    const { fcm_token } = req.body;
    if (!fcm_token) {
      return res.status(400).json({ success: false, message: 'FCM টোকেন আবশ্যক।' });
    }

    await User.findByIdAndUpdate(req.user._id, { fcm_token });

    res.status(200).json({
      success: true,
      message: 'FCM ডিভাইস টোকেন সফলভাবে সেভ হয়েছে।',
    });
  } catch (error) {
    next(error);
  }
};const