const User = require('../models/user.model');
const jwt = require('jsonwebtoken');

/**
 * JWT টোকেন তৈরি করার ইন্টারনাল হেল্পার ফাংশন
 */
const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, token_version: user.token_version },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '30d' }
  );
};

/**
 * @desc    নতুন ইউজার রেজিস্ট্রেশন (সাইন-আপ)
 * @route   POST /api/auth/register
 * @access  Public
 */
exports.register = async (req, res, next) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ success: false, message: 'সবগুলো ফিল্ড পূরণ করুন।' });
    }

    // ইউজারনেম বা ইমেইল ইতিমধ্যে ব্যবহৃত হয়েছে কি না চেক
    const userExists = await User.findOne({ $or: [{ email }, { username }] });
    if (userExists) {
      return res.status(400).json({ success: false, message: 'ইউজারনেম অথবা ইমেইল ইতিমধ্যে ব্যবহৃত হয়েছে।' });
    }

    // নতুন ইউজার অবজেক্ট তৈরি
    const user = await User.create({
      username,
      email,
      password,
    });

    const token = generateToken(user);

    res.status(201).json({
      success: true,
      message: 'রেজিস্ট্রেশন সফল হয়েছে!',
      data: {
        _id: user._id,
        username: user.username,
        email: user.email,
        avatar: user.avatar,
        wallet_balance: user.wallet_balance,
        token,
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    ইউজার লগইন ও সিকিউর টোকেন প্রদান
 * @route   POST /api/auth/login
 * @access  Public
 */
exports.login = async (req, res, next) => {
  try {
    const { identifier, password } = req.body; // ইমেইল বা ইউজারনেম

    if (!identifier || !password) {
      return res.status(400).json({ success: false, message: 'ইমেইল/ইউজারনেম এবং পাসওয়ার্ড প্রদান করুন।' });
    }

    // ইমেইল বা ইউজারনেম দিয়ে ইউজার খোঁজা এবং পাসওয়ার্ড ফিল্ড নিয়ে আসা
    const user = await User.findOne({
      $or: [{ email: identifier.toLowerCase() }, { username: identifier.toLowerCase() }],
    }).select('+password');

    if (!user) {
      return res.status(401).json({ success: false, message: 'ভুল ক্রেডেনশিয়াল!' });
    }

    // পাসওয়ার্ড ভ্যালিডেশন
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'ভুল ক্রেডেনশিয়াল!' });
    }

    // অ্যাকাউন্ট সাসপেনশন গার্ড
    if (user.is_suspended || user.strike_count >= 3) {
      return res.status(403).json({
        success: false,
        message: 'অ্যাকাউন্ট সাসপেন্ডেড! অ্যাডমিনের সাথে যোগাযোগ করুন।',
      });
    }

    const token = generateToken(user);

    res.status(200).json({
      success: true,
      message: 'লগইন সফল হয়েছে!',
      data: {
        _id: user._id,
        username: user.username,
        email: user.email,
        avatar: user.avatar,
        wallet_balance: user.wallet_balance,
        strike_count: user.strike_count,
        token,
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    লগইন করা ইউজারের নিজস্ব প্রোফাইল ডেটা লোড
 * @route   GET /api/auth/me
 * @access  Private (JWT প্রোটেক্টেড)
 */
exports.getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    next(error);
  }
};