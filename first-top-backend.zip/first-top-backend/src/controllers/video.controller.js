const Video = require('../models/video.model');
const Story = require('../models/story.model');
const User = require('../models/user.model');
const { generatePresignedUploadUrl } = require('../services/b2.service');
const { scanVideoWithHive } = require('../services/hive.service');

/**
 * @desc    Backblaze B2 Presigned Upload URL জেনারেট করা
 * @route   POST /api/videos/presigned-url
 * @access  Private
 */
exports.getUploadUrl = async (req, res, next) => {
  try {
    const { fileName, fileType } = req.body;
    if (!fileName || !fileType) {
      return res.status(400).json({ success: false, message: 'ফাইলের নাম এবং ধরন আবশ্যক।' });
    }

    const presignedData = await generatePresignedUploadUrl(fileName, fileType);
    res.status(200).json({
      success: true,
      message: 'Presigned URL সফলভাবে তৈরি হয়েছে।',
      data: presignedData,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    ভিডিও প্রকাশ ও Hive AI মডারেশন সম্পন্ন করা
 * @route   POST /api/videos/publish
 * @access  Private
 */
exports.publishVideo = async (req, res, next) => {
  try {
    const { video_url, thumbnail_url, caption, tags, duet_original_video, has_poll, poll_data, has_qa } = req.body;

    if (!video_url) {
      return res.status(400).json({ success: false, message: 'ভিডিও URL আবশ্যক।' });
    }

    // ১. Hive AI স্ক্যান
    const moderationResult = await scanVideoWithHive(video_url);

    // ক্ষতিকর কনটেন্ট হলে রিজেক্ট এবং ইউজারকে পেনাল্টি স্ট্রাইক দেওয়া
    if (!moderationResult.isClean) {
      const updatedUser = await User.findByIdAndUpdate(
        req.user._id,
        { $inc: { strike_count: 1 } },
        { new: true }
      );

      // ৩টি স্ট্রাইক পার হলে স্বয়ংক্রিয় অ্যাকাউন্ট সাসপেন্ড
      if (updatedUser.strike_count >= 3) {
        updatedUser.is_suspended = true;
        updatedUser.token_version += 1;
        await updatedUser.save();
      }

      return res.status(403).json({
        success: false,
        message: 'কমিউনিটি স্ট্যান্ডার্ড ভঙ্গের কারণে ভিডিওটি রিজেক্ট হয়েছে এবং অ্যাকাউন্টে ১টি স্ট্রাইক যোগ হয়েছে!',
        current_strikes: updatedUser.strike_count,
      });
    }

    // ২. স্ক্যান Clean হলে ভিডিও ডাটাবেসে সেভ করা
    const video = await Video.create({
      user: req.user._id,
      video_url,
      thumbnail_url,
      caption,
      tags,
      duet_original_video: duet_original_video || null,
      has_poll: !!has_poll,
      poll_data: has_poll ? poll_data : undefined,
      has_qa: !!has_qa,
      moderation_status: 'approved',
    });

    res.status(201).json({
      success: true,
      message: 'ভিডিও অনুমোদিত এবং পাবলিশ করা হয়েছে!',
      data: video,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    ৩-সেকেন্ড হাইলাইট রুল ও ভিউ ট্র্যাকিং
 * @route   POST /api/videos/:id/view
 * @access  Public/Private
 */
exports.recordWatchDuration = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { duration_seconds } = req.body;

    const video = await Video.findById(id);
    if (!video) {
      return res.status(404).json({ success: false, message: 'ভিডিও পাওয়া যায়নি।' });
    }

    video.views_count += 1;
    await User.findByIdAndUpdate(video.user, { $inc: { total_views: 1 } });

    // ৩-সেকেন্ড হাইলাইট রুল: কমপক্ষে ৩ সেকেন্ড দেখলে কাউন্ট বাড়বে
    if (duration_seconds && duration_seconds >= 3) {
      video.view_duration_count += 1;
    }

    // ফর-ইউ অ্যালগরিদম বুস্ট রেশিও যাচাই
    const engagementRatio = (video.likes_count + video.shares_count) / (video.views_count || 1);
    const retentionRatio = video.view_duration_count / (video.views_count || 1);

    if (video.views_count >= 50 && retentionRatio >= 0.5 && engagementRatio >= 0.1) {
      video.is_highlighted = true; // ফিডে বুস্ট পাবে
    }

    await video.save();

    res.status(200).json({
      success: true,
      is_highlighted: video.is_highlighted,
      views_count: video.views_count,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    ফর-ইউ ফিড ফেচ করা
 * @route   GET /api/videos/feed
 * @access  Public
 */
exports.getForYouFeed = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    // প্রথমে হাইলাইটেড এবং অনুমোদিত ভিডিওগুলো আগে দেখানো
    const feed = await Video.find({ moderation_status: 'approved' })
      .populate('user', 'username avatar total_views')
      .populate('duet_original_video', 'video_url user')
      .sort({ is_highlighted: -1, createdAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      success: true,
      page,
      results: feed.length,
      data: feed,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    ২৪ ঘণ্টার স্টোরি তৈরি
 * @route   POST /api/videos/stories
 * @access  Private
 */
exports.createStory = async (req, res, next) => {
  try {
    const { media_url, media_type } = req.body;
    if (!media_url) {
      return res.status(400).json({ success: false, message: 'মিডিয়া URL আবশ্যক।' });
    }

    const story = await Story.create({
      user: req.user._id,
      media_url,
      media_type: media_type || 'video',
    });

    res.status(201).json({
      success: true,
      message: 'স্টোরি পাবলিশ করা হয়েছে (২৪ ঘণ্টা পর মুছে যাবে)।',
      data: story,
    });
  } catch (error) {
    next(error);
  }
};