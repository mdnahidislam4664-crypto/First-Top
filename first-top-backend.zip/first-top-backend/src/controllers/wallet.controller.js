const mongoose = require('mongoose');
const User = require('../models/user.model');
const Transaction = require('../models/transaction.model');
const GlobalSettings = require('../models/settings.model');

// ১. কয়েন গিফট সেন্ডিং
exports.sendGiftCoin = async (req, res, next) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const { receiver_id, amount, password } = req.body;
    const senderId = req.user._id;

    if (!receiver_id || !amount || !password) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ success: false, message: 'প্রাপক, পরিমাণ এবং পাসওয়ার্ড আবশ্যক।' });
    }

    if (amount <= 0) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ success: false, message: 'ভ্যালিড পরিমাণ দিন।' });
    }

    if (senderId.toString() === receiver_id.toString()) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ success: false, message: 'নিজেকে কয়েন পাঠানো যাবে না।' });
    }

    const sender = await User.findById(senderId).select('+password').session(session);
    const isPasswordValid = await sender.matchPassword(password);

    if (!isPasswordValid) {
      await session.abortTransaction();
      session.endSession();
      return res.status(401).json({ success: false, message: 'ভুল পাসওয়ার্ড! লেনদেন বাতিল।' });
    }

    if (sender.wallet_balance < amount) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ success: false, message: 'পর্যাপ্ত ব্যালেন্স নেই।' });
    }

    const receiver = await User.findById(receiver_id).session(session);
    if (!receiver) {
      await session.abortTransaction();
      session.endSession();
      return res.status(404).json({ success: false, message: 'প্রাপক খুঁজে পাওয়া যায়নি।' });
    }

    await User.findByIdAndUpdate(senderId, { $inc: { wallet_balance: -amount } }, { session });
    await User.findByIdAndUpdate(receiver_id, { $inc: { wallet_balance: amount } }, { session });

    const transaction = await Transaction.create(
      [{ sender: senderId, receiver: receiver_id, amount, type: 'gift', status: 'completed' }],
      { session }
    );

    await session.commitTransaction();
    session.endSession();

    res.status(200).json({ success: true, message: `${amount} কয়েন সফলভাবে পাঠানো হয়েছে।`, data: transaction[0] });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    next(error);
  }
};

// ২. ডিপোজিট রিকোয়েস্ট
exports.createDepositRequest = async (req, res, next) => {
  try {
    const { amount, payment_method, transaction_id } = req.body;
    if (!amount || !payment_method || !transaction_id) {
      return res.status(400).json({ success: false, message: 'সব তথ্য প্রদান করুন।' });
    }

    const deposit = await Transaction.create({
      receiver: req.user._id,
      amount,
      type: 'deposit',
      status: 'pending',
      payment_method,
      transaction_id,
    });

    res.status(201).json({ success: true, message: 'ডিপোজিট রিকোয়েস্ট জমা হয়েছে।', data: deposit });
  } catch (error) {
    next(error);
  }
};

// ৩. উইথড্র / ক্যাশআউট রিকোয়েস্ট (পাসওয়ার্ড ও ব্যালেন্স হোল্ড সহ)
exports.createWithdrawRequest = async (req, res, next) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const { amount, payment_method, account_number, password } = req.body;
    const userId = req.user._id;

    if (!amount || !payment_method || !account_number || !password) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ success: false, message: 'সব তথ্য ও পাসওয়ার্ড প্রদান করুন।' });
    }

    const user = await User.findById(userId).select('+password').session(session);
    const isPasswordValid = await user.matchPassword(password);
    if (!isPasswordValid) {
      await session.abortTransaction();
      session.endSession();
      return res.status(401).json({ success: false, message: 'ভুল পাসওয়ার্ড! লেনদেন বাতিল।' });
    }

    const settings = await GlobalSettings.findOne().session(session);
    const minWithdraw = settings ? settings.min_withdrawal_bdt : 500;
    if (amount < minWithdraw) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ success: false, message: `সর্বনিম্ন উইথড্র সীমা ${minWithdraw} টাকা।` });
    }

    if (user.wallet_balance < amount) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ success: false, message: 'পর্যাপ্ত ব্যালেন্স নেই।' });
    }

    // ব্যালেন্স হোল্ড করা
    await User.findByIdAndUpdate(userId, { $inc: { wallet_balance: -amount } }, { session });

    const withdrawal = await Transaction.create(
      [
        {
          receiver: userId,
          amount,
          type: 'withdrawal',
          status: 'pending',
          payment_method,
          transaction_id: account_number,
        },
      ],
      { session }
    );

    await session.commitTransaction();
    session.endSession();

    res.status(201).json({ success: true, message: 'উইথড্র রিকোয়েস্ট জমা হয়েছে।', data: withdrawal[0] });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    next(error);
  }
};

// ৪. অ্যাডমিন ডিপোজিট অ্যাপ্রুভ
exports.approveDeposit = async (req, res, next) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const { id } = req.params;
    const transaction = await Transaction.findById(id).session(session);

    if (!transaction || transaction.status !== 'pending') {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ success: false, message: 'অবৈধ ট্রানজেকশন।' });
    }

    transaction.status = 'completed';
    await transaction.save({ session });

    await User.findByIdAndUpdate(transaction.receiver, { $inc: { wallet_balance: transaction.amount } }, { session });

    await session.commitTransaction();
    session.endSession();

    res.status(200).json({ success: true, message: 'ডিপোজিট সফল হয়েছে এবং ব্যালেন্স যোগ হয়েছে।', data: transaction });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    next(error);
  }
};

// ৫. নিজের লেনদেন হিস্ট্রি
exports.getMyTransactions = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;

    const transactions = await Transaction.find({
      $or: [{ sender: req.user._id }, { receiver: req.user._id }],
    })
      .populate('sender', 'username avatar')
      .populate('receiver', 'username avatar')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    res.status(200).json({ success: true, results: transactions.length, data: transactions });
  } catch (error) {
    next(error);
  }
};