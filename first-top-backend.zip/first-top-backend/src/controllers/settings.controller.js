const GlobalSettings = require('../models/settings.model');

const getOrCreateSettings = async () => {
  let settings = await GlobalSettings.findOne();
  if (!settings) {
    settings = await GlobalSettings.create({});
  }
  return settings;
};

/**
 * @desc    স্টার্টআপ কনফিগারেশন ফেচ করা
 * @route   GET /api/settings
 * @access  Public
 */
exports.getSettings = async (req, res, next) => {
  try {
    const settings = await getOrCreateSettings();
    res.status(200).json({
      success: true,
      message: 'গ্লোবাল সেটিংস লোড হয়েছে।',
      data: settings,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    অ্যাডমিন প্যানেল থেকে সেটিংস আপডেট করা
 * @route   PATCH /api/settings
 * @access  Private
 */
exports.updateSettings = async (req, res, next) => {
  try {
    const settings = await getOrCreateSettings();
    Object.assign(settings, req.body);
    await settings.save();

    res.status(200).json({
      success: true,
      message: 'গ্লোবাল সেটিংস সফলভাবে আপডেট হয়েছে।',
      data: settings,
    });
  } catch (error) {
    next(error);
  }
};const