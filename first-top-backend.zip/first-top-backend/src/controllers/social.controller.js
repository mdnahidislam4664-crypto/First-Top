const Video = require('../models/video.model');
const Comment = require('../models/comment.model');
const Like = require('../models/like.model');
const Follow = require('../models/follow.model');
const Notification = require('../models/notification.model');
const User = require('../models/user.model');
const GlobalSettings = require('../models/settings.model');

// ১. লাইক টগল (Like / Unlike)
exports.toggleLike = async (req, res, next) => {
  try {
    const { videoId } = req.params;
    const userId = req.user._id;

    const existingLike = await Like.findOne({ user: userId, video: videoId });

    if (existingLike) {
      await Like.findByIdAndDelete(existingLike._id);
      await Video.findByIdAndUpdate(videoId, { $inc: { likes_count: -1 } });
      return res.status(200).json({ success: true, isLiked: false });
    } else {
      await Like.create({ user: userId, video: videoId });
      const video = await Video.findByIdAndUpdate(videoId, { $inc: { likes_count: 1 } });

      // ক্রিয়েটরকে নোটিফিকেশন পাঠানো
      if (video.user.toString() !== userId.toString()) {
        await Notification.create({
          recipient: video.user,
          sender: userId,
          type: 'like',
          video: video._id,
          message: `@${req.user.username} আপনার ভিডিওতে লাইক দিয়েছেন।`,
        });
      }

      return res.status(200).json({ success: true, isLiked: true });
    }
  } catch (error) {
    next(error);
  }
};

// ২. ফলো টগল (Follow / Unfollow)
exports.toggleFollow = async (req, res, next) => {
  try {
    const { targetUserId } = req.params;
    const currentUserId = req.user._id;

    if (targetUserId === currentUserId.toString()) {
      return res.status(400).json({ success: false, message: 'নিজেকে ফলো করা যাবে না।' });
    }

    const existingFollow = await Follow.findOne({ follower: currentUserId, following: targetUserId });

    if (existingFollow) {
      await Follow.findByIdAndDelete(existingFollow._id);
      await User.findByIdAndUpdate(currentUserId, { $inc: { following_count: -1 } });
      await User.findByIdAndUpdate(targetUserId, { $inc: { followers_count: -1 } });
      return res.status(200).json({ success: true, isFollowing: false });
    } else {
      await Follow.create({ follower: currentUserId, following: targetUserId });
      await User.findByIdAndUpdate(currentUserId, { $inc: { following_count: 1 } });
      await User.findByIdAndUpdate(targetUserId, { $inc: { followers_count: 1 } });

      await Notification.create({
        recipient: targetUserId,
        sender: currentUserId,
        type: 'follow',
        message: `@${req.user.username} আপনাকে ফলো করা শুরু করেছেন।`,
      });

      return res.status(200).json({ success: true, isFollowing: true });
    }
  } catch (error) {
    next(error);
  }
};

// ৩. নতুন কমেন্ট
exports.addComment = async (req, res, next) => {
  try {
    const { videoId } = req.params;
    const { text, parent_comment } = req.body;

    if (!text || text.trim() === '') {
      return res.status(400).json({ success: false, message: 'কমেন্ট টেক্সট আবশ্যক।' });
    }

    const video = await Video.findById(videoId);
    if (!video || !video.allow_comments) {
      return res.status(403).json({ success: false, message: 'এই ভিডিওতে কমেন্ট বন্ধ আছে।' });
    }

    const comment = await Comment.create({
      video: videoId,
      user: req.user._id,
      text: text.trim(),
      parent_comment: parent_comment || null,
    });

    await Video.findByIdAndUpdate(videoId, { $inc: { comments_count: 1 } });

    if (video.user.toString() !== req.user._id.toString()) {
      await Notification.create({
        recipient: video.user,
        sender: req.user._id,
        type: 'comment',
        video: video._id,
        message: `@${req.user.username} আপনার ভিডিওতে কমেন্ট করেছেন: "${text.substring(0, 30)}..."`,
      });
    }

    res.status(201).json({ success: true, data: comment });
  } catch (error) {
    next(error);
  }
};

// ৪. কমেন্ট লিস্ট (পিনড কমেন্ট সবার আগে থাকবে)
exports.getComments = async (req, res, next) => {
  try {
    const { videoId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;

    const comments = await Comment.find({ video: videoId, parent_comment: null })
      .populate('user', 'username avatar')
      .sort({ is_pinned: -1, createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    res.status(200).json({ success: true, results: comments.length, data: comments });
  } catch (error) {
    next(error);
  }
};

// ৫. ক্রিয়েটর কর্তৃক সেরা কমেন্ট পিন (Pin Comment) করা
exports.togglePinComment = async (req, res, next) => {
  try {
    const { commentId } = req.params;
    const comment = await Comment.findById(commentId).populate('video');

    if (!comment) return res.status(404).json({ success: false, message: 'কমেন্ট পাওয়া যায়নি।' });
    if (comment.video.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'অননুমোদিত! শুধুমাত্র ক্রিয়েটর কমেন্ট পিন করতে পারেন।' });
    }

    if (!comment.is_pinned) {
      await Comment.updateMany({ video: comment.video._id, is_pinned: true }, { is_pinned: false });
    }

    comment.is_pinned = !comment.is_pinned;
    await comment.save();

    res.status(200).json({ success: true, is_pinned: comment.is_pinned });
  } catch (error) {
    next(error);
  }
};

// ৬. জিপিএস ও এলাকা-ভিত্তিক Nearby ফিড (GeoJSON 2dsphere)
exports.getNearbyFeed = async (req, res, next) => {
  try {
    const { longitude, latitude } = req.query;

    if (!longitude || !latitude) {
      return res.status(400).json({ success: false, message: 'জিপিএস কোঅর্ডিনেট (longitude, latitude) প্রয়োজন।' });
    }

    const settings = await GlobalSettings.findOne();
    const radiusKm = settings ? settings.default_nearby_radius_km : 25;
    const radiusInMeters = radiusKm * 1000;

    const nearbyVideos = await Video.find({
      moderation_status: 'approved',
      location: {
        $near: {
          $geometry: { type: 'Point', coordinates: [parseFloat(longitude), parseFloat(latitude)] },
          $maxDistance: radiusInMeters,
        },
      },
    })
      .populate('user', 'username avatar')
      .limit(20);

    res.status(200).json({ success: true, radius_km: radiusKm, results: nearbyVideos.length, data: nearbyVideos });
  } catch (error) {
    next(error);
  }
};

// ৭. ইন-অ্যাপ নোটিফিকেশন লিস্ট
exports.getMyNotifications = async (req, res, next) => {
  try {
    const notifications = await Notification.find({ recipient: req.user._id })
      .populate('sender', 'username avatar')
      .populate('video', 'thumbnail_url')
      .sort({ createdAt: -1 })
      .limit(30);

    await Notification.updateMany({ recipient: req.user._id, is_read: false }, { is_read: true });

    res.status(200).json({ success: true, data: notifications });
  } catch (error) {
    next(error);
  }
};