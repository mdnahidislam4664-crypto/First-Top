const User = require('../models/user.model');
const Video = require('../models/video.model');
const Transaction = require('../models/transaction.model');
const mongoose = require('mongoose');

// ================= অ্যাডমিন অ্যাপ ১: ইউজার, ক্রিয়েটর ও ফাইন্যান্স =================

// ১. সমস্ত ইউজারের তালিকা
exports.getAllUsers = async (req, res, next) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    let query = {};
    if (search) {
      query.$or = [{ username: { $regex: search, $options: 'i' } }, { email: { $regex: search, $options: 'i' } }];
    }
    const users = await User.find(query).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(parseInt(limit));
    const total = await User.countDocuments(query);
    res.status(200).json({ success: true, total, data: users });
  } catch (error) {
    next(error);
  }
};

// ২. ইউজার সাসপেনশন, ব্লু-টিক ও মনিটাইজেশন পারমিশন
exports.updateUserStatus = async (req, res, next) => {
  try {
    const { userId } = req.params;
    const { is_suspended, is_monetized, reset_strikes } = req.body;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ success: false, message: 'ইউজার পাওয়া যায়নি।' });

    if (is_suspended !== undefined) {
      user.is_suspended = is_suspended;
      if (is_suspended) user.token_version += 1;
    }
    if (is_monetized !== undefined) user.is_monetized = is_monetized;
    if (reset_strikes) user.strike_count = 0;

    await user.save();
    res.status(200).json({ success: true, message: 'ইউজার স্ট্যাটাস আপডেট হয়েছে।', data: user });
  } catch (error) {
    next(error);
  }
};

// ৩. পেন্ডিং উইথড্র / ক্যাশআউট তালিকা
exports.getPendingWithdrawals = async (req, res, next) => {
  try {
    const withdrawals = await Transaction.find({ type: 'withdrawal', status: 'pending' })
      .populate('receiver', 'username email wallet_balance')
      .sort({ createdAt: -1 });
    res.status(200).json({ success: true, results: withdrawals.length, data: withdrawals });
  } catch (error) {
    next(error);
  }
};

// ৪. উইথড্র প্রসেস (Mark as Paid অথবা Reject ও রিফান্ড)
exports.processWithdrawal = async (req, res, next) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { transactionId } = req.params;
    const { action, admin_note } = req.body;
    const trx = await Transaction.findById(transactionId).session(session);

    if (!trx || trx.status !== 'pending' || trx.type !== 'withdrawal') {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ success: false, message: 'অবৈধ ট্রানজেকশন।' });
    }

    if (action === 'approve') {
      trx.status = 'completed';
      trx.admin_note = admin_note || 'পেমেন্ট সম্পন্ন হয়েছে।';
      await trx.save({ session });
    } else if (action === 'reject') {
      trx.status = 'rejected';
      trx.admin_note = admin_note || 'পেমেন্ট বাতিল ও ব্যালেন্স রিফান্ড করা হয়েছে।';
      await trx.save({ session });
      // রিজেক্ট হলে টাকা স্বয়ংক্রিয়ভাবে ইউজারের ওয়ালেটে রিফান্ড হবে (Atomic Refund)
      await User.findByIdAndUpdate(trx.receiver, { $inc: { wallet_balance: trx.amount } }, { session });
    }

    await session.commitTransaction();
    session.endSession();
    res.status(200).json({ success: true, message: `উইথড্র ${action} করা হয়েছে।`, data: trx });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    next(error);
  }
};

// ================= অ্যাডমিন অ্যাপ ২: কন্টেন্ট মডারেশন ও ইঞ্জিন =================

// ৫. ফ্ল্যাগড ও ক্ষতিকর ভিডিও তালিকা
exports.getFlaggedVideos = async (req, res, next) => {
  try {
    const videos = await Video.find({ moderation_status: { $in: ['pending', 'rejected'] } })
      .populate('user', 'username email strike_count')
      .sort({ createdAt: -1 });
    res.status(200).json({ success: true, results: videos.length, data: videos });
  } catch (error) {
    next(error);
  }
};

// ৬. ভিডিও ডিলিট ও ক্রিয়েটরকে ম্যানুয়াল স্ট্রাইক দেওয়া
exports.deleteVideoAndPenalize = async (req, res, next) => {
  try {
    const { videoId } = req.params;
    const { give_strike } = req.body;
    const video = await Video.findById(videoId);
    if (!video) return res.status(404).json({ success: false, message: 'ভিডিও পাওয়া যায়নি।' });

    if (give_strike) {
      const creator = await User.findByIdAndUpdate(video.user, { $inc: { strike_count: 1 } }, { new: true });
      if (creator.strike_count >= 3) {
        creator.is_suspended = true;
        creator.token_version += 1;
        await creator.save();
      }
    }

    await Video.findByIdAndDelete(videoId);
    res.status(200).json({ success: true, message: 'ভিডিও ডিলিট এবং পেনাল্টি প্রয়োগ করা হয়েছে।' });
  } catch (error) {
    next(error);
  }
};