const mongoose = require('mongoose');
const User = require('../models/user.model');
const Video = require('../models/video.model');
const Earning = require('../models/earning.model');
const GlobalSettings = require('../models/settings.model');

/**
 * @desc    মনিটাইজেশন যোগ্যতা যাচাই
 * @route   GET /api/monetization/check-eligibility
 * @access  Private
 */
exports.checkEligibility = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    let settings = await GlobalSettings.findOne();
    if (!settings) settings = await GlobalSettings.create({});

    const minViews = settings.monetization_min_views;
    const minFollowers = settings.monetization_min_followers;

    const isEligible = user.total_views >= minViews && user.followers_count >= minFollowers;

    res.status(200).json({
      success: true,
      data: {
        is_eligible_for_monetization: isEligible,
        is_already_monetized: user.is_monetized,
        current_views: user.total_views,
        required_views: minViews,
        current_followers: user.followers_count,
        required_followers: minFollowers,
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    অ্যাড ইম্প্রেশন ও ৫০% রেভিনিউ শেয়ারিং লজিক
 * @route   POST /api/monetization/ad-impression
 * @access  Public/Private
 */
exports.recordAdImpression = async (req, res, next) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const { video_id } = req.body;
    if (!video_id) {
      await session.abortTransaction();
      session.endSession();
      return res.status(400).json({ success: false, message: 'ভিডিও আইডি আবশ্যক।' });
    }

    const video = await Video.findById(video_id).populate('user').session(session);
    if (!video) {
      await session.abortTransaction();
      session.endSession();
      return res.status(404).json({ success: false, message: 'ভিডিও পাওয়া যায়নি।' });
    }

    const settings = await GlobalSettings.findOne().session(session);
    const totalAdRevenue = settings ? settings.ad_base_cpm_rate : 0.02;

    const creator = video.user;
    let creatorShare = 0;
    let platformShare = totalAdRevenue;

    // ৫০% অ্যাড রেভিনিউ স্প্লিট বিজনেস লজিক
    if (creator.is_monetized) {
      creatorShare = totalAdRevenue * 0.5; // ৫০% ক্রিয়েটরের
      platformShare = totalAdRevenue * 0.5; // ৫০% প্ল্যাটফর্মের

      // ক্রিয়েটরের ওয়ালেটে ৫০% আয় ক্রেডিট
      await User.findByIdAndUpdate(
        creator._id,
        { $inc: { wallet_balance: creatorShare } },
        { session }
      );
    } else {
      creatorShare = 0;
      platformShare = totalAdRevenue; // ১০০% প্ল্যাটফর্মের
    }

    // লেজারে সংরক্ষণ
    await Earning.create(
      [
        {
          creator: creator._id,
          video: video._id,
          total_ad_revenue: totalAdRevenue,
          creator_share: creatorShare,
          platform_share: platformShare,
        },
      ],
      { session }
    );

    await session.commitTransaction();
    session.endSession();

    res.status(200).json({
      success: true,
      message: 'অ্যাড ইম্প্রেশন ও রেভিনিউ হিসেব সম্পন্ন হয়েছে।',
      creator_monetized: creator.is_monetized,
      credited_share: creatorShare,
    });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    next(error);
  }
};

/**
 * @desc    ক্রিয়েটর ড্যাশবোর্ড অ্যানালিটিক্স (Views, Estimated Earnings, RPM)
 * @route   GET /api/monetization/creator-dashboard
 * @access  Private
 */
exports.getCreatorDashboardAnalytics = async (req, res, next) => {
  try {
    const creatorId = req.user._id;

    // সর্বমোট অর্জিত আয়
    const totalEarningsResult = await Earning.aggregate([
      { $match: { creator: new mongoose.Types.ObjectId(creatorId) } },
      { $group: { _id: null, total: { $sum: '$creator_share' } } },
    ]);

    const totalEstimatedEarnings = totalEarningsResult[0]?.total || 0;
    const totalViews = req.user.total_views || 1;

    // RPM = (Total Earnings / Total Views) * 1000
    const calculatedRPM = ((totalEstimatedEarnings / totalViews) * 1000).toFixed(3);

    res.status(200).json({
      success: true,
      data: {
        total_views: totalViews,
        total_estimated_earnings: totalEstimatedEarnings,
        rpm: parseFloat(calculatedRPM),
      },
    });
  } catch (error) {
    next(error);
  }
};