const express = require('express');
const router = express.Router();
const { getChatHistory, updateFcmToken } = require('../controllers/chat.controller');
const { protect } = require('../middlewares/auth.middleware');

// ১. দুই ইউজারের চ্যাট হিস্ট্রি লোড করার এন্ডপয়েন্ট (লগইন আবশ্যক)
router.get('/:receiverId', protect, getChatHistory);

// ২. অফলাইন পুশ নোটিফিকেশনের জন্য ডিভাইসের FCM টোকেন সেভ করার এন্ডপয়েন্ট
router.post('/fcm-token', protect, updateFcmToken);

module.exports = router;