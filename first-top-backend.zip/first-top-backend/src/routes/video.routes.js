const express = require('express');
const router = express.Router();
const {
  getUploadUrl,
  publishVideo,
  recordWatchDuration,
  getForYouFeed,
  createStory,
} = require('../controllers/video.controller');
const { protect } = require('../middlewares/auth.middleware');

// ১. ফর-ইউ ফিড ফেচ করা (পাবলিক)
router.get('/feed', getForYouFeed);

// ২. ভিডিও ওয়াচ টাইম ও ভিউ কাউন্ট রেকর্ড (৩-সেকেন্ড হাইলাইট রুল)
router.post('/:id/view', recordWatchDuration);

// ৩. Backblaze B2 প্রিসাইন্ড URL নেওয়া (প্রোটেক্টেড)
router.post('/presigned-url', protect, getUploadUrl);

// ৪. ভিডিও পাবলিশ ও Hive AI মডারেশন (প্রোটেক্টেড)
router.post('/publish', protect, publishVideo);

// ৫. ২৪ ঘণ্টার স্টোরি আপলোড (প্রোটেক্টেড)
router.post('/stories', protect, createStory);

module.exports = router;