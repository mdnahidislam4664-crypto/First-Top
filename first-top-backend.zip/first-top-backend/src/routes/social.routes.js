const express = require('express');
const router = express.Router();
const {
  toggleLike,
  toggleFollow,
  addComment,
  getComments,
  togglePinComment,
  getNearbyFeed,
  getMyNotifications,
} = require('../controllers/social.controller');
const { protect } = require('../middlewares/auth.middleware');

// লাইক, ফলো ও কমেন্ট
router.post('/videos/:videoId/like', protect, toggleLike);
router.post('/users/:targetUserId/follow', protect, toggleFollow);
router.post('/videos/:videoId/comments', protect, addComment);
router.get('/videos/:videoId/comments', getComments);
router.patch('/comments/:commentId/pin', protect, togglePinComment);

// জিপিএস এলাকা-ভিত্তিক Nearby ভিডিও
router.get('/videos/nearby', getNearbyFeed);

// নোটিফিকেশন সেন্টার
router.get('/notifications', protect, getMyNotifications);

module.exports = router;