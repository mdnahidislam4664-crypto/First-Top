const express = require('express');
const router = express.Router();
const { register, login, getMe } = require('../controllers/auth.controller');
const { protect } = require('../middlewares/auth.middleware');

// পাবলিক রাউটস (লগইন ছাড়া অ্যাক্সেসযোগ্য)
router.post('/register', register);
router.post('/login', login);

// প্রাইভেট রাউটস (লগইন টোকেন আবশ্যক)
router.get('/me', protect, getMe);

module.exports = router;