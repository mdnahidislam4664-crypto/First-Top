const express = require('express');
const router = express.Router();
const {
  sendGiftCoin,
  createDepositRequest,
  createWithdrawRequest,
  approveDeposit,
  getMyTransactions,
} = require('../controllers/wallet.controller');
const { protect } = require('../middlewares/auth.middleware');

router.post('/send-gift', protect, sendGiftCoin);
router.post('/deposit-request', protect, createDepositRequest);
router.post('/withdraw-request', protect, createWithdrawRequest); // উইথড্র এন্ডপয়েন্ট
router.get('/my-transactions', protect, getMyTransactions);
router.patch('/admin/approve-deposit/:id', protect, approveDeposit);

module.exports = router;