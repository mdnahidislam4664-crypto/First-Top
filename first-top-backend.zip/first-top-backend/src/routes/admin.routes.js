const express = require('express');
const router = express.Router();
const {
  getAllUsers,
  updateUserStatus,
  getPendingWithdrawals,
  processWithdrawal,
  getFlaggedVideos,
  deleteVideoAndPenalize,
} = require('../controllers/admin.controller');
const { protect } = require('../middlewares/auth.middleware');

// অ্যাডমিন ১: ইউজার, ক্রিয়েটর ও উইথড্র ফাইন্যান্স
router.get('/users', protect, getAllUsers);
router.patch('/users/:userId/status', protect, updateUserStatus);
router.get('/withdrawals', protect, getPendingWithdrawals);
router.patch('/withdrawals/:transactionId/process', protect, processWithdrawal);

// অ্যাডমিন ২: ক্ষতিকর কন্টেন্ট ও স্ট্রাইক পেনাল্টি
router.get('/videos/flagged', protect, getFlaggedVideos);
router.delete('/videos/:videoId', protect, deleteVideoAndPenalize);

module.exports = router;