const express = require('express');
const router = express.Router();
const {
  checkEligibility,
  recordAdImpression,
  getCreatorDashboardAnalytics,
} = require('../controllers/monetization.controller');
const { protect } = require('../middlewares/auth.middleware');

// ১. ইউজারের মনিটাইজেশন পাওয়ার যোগ্যতা যাচাই
router.get('/check-eligibility', protect, checkEligibility);

// ২. ভিডিওতে অ্যাড ইম্প্রেশন রেকর্ড ও ৫০% রেভিনিউ শেয়ারিং লজিক
router.post('/ad-impression', recordAdImpression);

// ৩. ক্রিয়েটর স্টুডিও অ্যানালিটিক্স (Views, Estimated Earnings, RPM)
router.get('/creator-dashboard', protect, getCreatorDashboardAnalytics);

module.exports = router;