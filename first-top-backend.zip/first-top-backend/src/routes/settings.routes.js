const express = require('express');
const router = express.Router();
const { getSettings, updateSettings } = require('../controllers/settings.controller');
const { protect } = require('../middlewares/auth.middleware');

// ১. পাবলিকলি কনফিগ লোড (অ্যাপ স্টার্টআপে ডায়নামিক সেটিংস ফেচ করা)
router.get('/', getSettings);

// ২. অ্যাডমিন প্যানেল থেকে গ্লোবাল সেটিংস আপডেট করা (প্রোটেক্টেড)
router.patch('/', protect, updateSettings);

module.exports = router;