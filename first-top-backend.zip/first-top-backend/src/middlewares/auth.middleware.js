const jwt = require('jsonwebtoken');
const User = require('../models/user.model');

/**
 * সিকিউর JWT প্রোটেকশন মিডলওয়্যার
 * ইউজারের টোকেন ভ্যালিডিটি, স্ট্রাইক কাউন্ট ও সাসপেনশন স্ট্যাটাস যাচাই করে
 */
const protect = async (req, res, next) => {
  let token;

  // হেডারে Bearer টোকেন আছে কি না চেক
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({ 
      success: false, 
      message: 'অননুমোদিত অ্যাক্সেস! কোনো টোকেন পাওয়া যায়নি।' 
    });
  }

  try {
    // ১. টোকেন ডিকোড করা
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // ২. ডেটাবেস থেকে ইউজারের লেটেস্ট তথ্য ফেচ করা
    const user = await User.findById(decoded.id).select('+password');

    if (!user) {
      return res.status(401).json({ 
        success: false, 
        message: 'ইউজার আর বিদ্যমান নেই বা ডিলিট করা হয়েছে।' 
      });
    }

    // ৩. অটো-পেনাল্টি চেক: ৩টি স্ট্রাইক হলে অ্যাকাউন্ট স্বয়ংক্রিয়ভাবে ব্লক থাকবে
    if (user.is_suspended || user.strike_count >= 3) {
      return res.status(403).json({
        success: false,
        message: 'কমিউনিটি স্ট্যান্ডার্ড লঙ্ঘনের কারণে আপনার অ্যাকাউন্টটি সাসপেন্ড করা হয়েছে।',
      });
    }

    // ৪. টোকেন ভার্সন ভ্যালিডেশন (পাসওয়ার্ড বদলালে পুরনো সেশন বাতিল করার জন্য)
    if (decoded.token_version !== user.token_version) {
      return res.status(401).json({ 
        success: false, 
        message: 'সেশনের মেয়াদ শেষ হয়েছে, অনুগ্রহ করে পুনরায় লগইন করুন।' 
      });
    }

    // ভ্যালিড ইউজারকে রিকোয়েস্ট অবজেক্টে যুক্ত করা
    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ 
      success: false, 
      message: 'টোকেনটি অবৈধ অথবা এক্সপায়ার হয়ে গেছে।' 
    });
  }
};

module.exports = { protect };