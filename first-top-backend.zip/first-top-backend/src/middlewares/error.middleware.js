/**
 * সেন্ট্রালাইজড গ্লোবাল এরর হ্যান্ডলার মিডলওয়্যার
 * প্রোডাকশনে ইন্টারনাল সার্ভার এররের সেন্সিটিভ স্ট্যাক ট্রেস লুকিয়ে রাখে এবং ক্লিন JSON রেসপন্স দেয়
 */
const errorHandler = (err, req, res, next) => {
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  res.status(statusCode).json({
    success: false,
    message: err.message || 'ইন্টারনাল সার্ভার ত্রুটি!',
    stack: process.env.NODE_ENV === 'production' ? null : err.stack,
  });
};

module.exports = errorHandler;