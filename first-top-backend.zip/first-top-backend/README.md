# First Top - Short Video & Social Media Backend

## Features
- **MVC Architecture**: Clean separation of Models, Views/Routes, and Controllers.
- **Security**: JWT Authentication, Bcrypt Password Hashing, Auto-Suspension on 3 Strikes.
- **Cloud Storage**: Backblaze B2 Direct Presigned Uploads.
- **AI Moderation**: Hive Moderation API Integration.
- **Video Algorithm**: 3-Second Highlight Rule & Recommendation Boost.
- **Stories**: 24-hour Auto-Expiring Stories via MongoDB TTL Index.
- **Real-Time Messenger**: Socket.io with 3-State Read Receipts (Sent=0, Delivered=1, Seen=2).
- **Push Alerts**: Firebase Cloud Messaging (FCM) for offline users.
- **ACID Transactions**: MongoDB Atomic Sessions for Coin Gifting & Balance Transfers.
- **Monetization**: 50% Ad Revenue Split Engine & Creator Studio Analytics (Views, RPM, Earnings).
- **Dynamic Config**: AdMob, Ad Frequency, and Payment Gateways fetched dynamically via API.